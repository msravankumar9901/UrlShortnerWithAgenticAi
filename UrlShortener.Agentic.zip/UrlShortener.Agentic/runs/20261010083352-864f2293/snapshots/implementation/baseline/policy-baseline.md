# Governance baseline
This node does not depend on the requirement text.
Controls that stay in force for every scenario:
- Agents write only inside the stage allow-list.
- Security and review stages are read-only.
- High-impact stages wait for a human approval, or for --auto-approve in a non-interactive demo.
- The audit log is append-only and hash-chained.
- A STOP file, max step count, or max duration ends the run without discarding state.