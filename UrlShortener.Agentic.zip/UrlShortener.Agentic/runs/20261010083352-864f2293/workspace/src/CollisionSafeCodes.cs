namespace Workspace.Sketch;

// Collision-safe allocation sketch. The production copy lives in JsonUrlRepository.
public static class CollisionSafeCodes
{
    public const int MaxAttempts = 8;

    public static string Allocate(Func<string> next, Func<string, bool> taken)
    {
        for (var attempt = 0; attempt < MaxAttempts; attempt++)
        {
            var code = next();
            if (!taken(code))
                return code;
        }

        throw new InvalidOperationException("Could not allocate a unique short code.");
    }
}