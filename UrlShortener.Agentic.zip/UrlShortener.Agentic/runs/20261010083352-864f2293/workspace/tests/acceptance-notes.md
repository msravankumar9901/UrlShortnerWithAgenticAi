# Acceptance notes
The authoritative suite is tests/UrlShortener.Tests.
This stage runs that suite and records the exit code. It does not weaken tests.
Covered: create, invalid scheme, SSRF, redirect, missing, expired, alias conflict, stats, concurrency, atomic write, rate limit, idempotent shorten.